
import React from 'react';
import { CalculationResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  result: CalculationResult | null;
}

const Dashboard: React.FC<DashboardProps> = ({ result }) => {
  if (!result) return null;

  const data = [
    { name: 'Cost', value: result.cost },
    { name: 'Revenue', value: result.revenue },
    { name: 'Profit', value: result.profit },
  ];

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800/50 p-5 rounded-2xl border border-slate-700">
          <p className="text-slate-400 text-sm">Estimated Revenue</p>
          <p className="text-2xl font-bold text-white mt-1">{formatCurrency(result.revenue)}</p>
        </div>
        <div className="bg-slate-800/50 p-5 rounded-2xl border border-slate-700">
          <p className="text-slate-400 text-sm">Total Cost</p>
          <p className="text-2xl font-bold text-white mt-1">{formatCurrency(result.cost)}</p>
        </div>
        <div className={`bg-slate-800/50 p-5 rounded-2xl border border-slate-700 ${result.profit >= 0 ? 'border-emerald-500/30' : 'border-red-500/30'}`}>
          <p className="text-slate-400 text-sm">Net Profit</p>
          <p className={`text-2xl font-bold mt-1 ${result.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {formatCurrency(result.profit)}
          </p>
        </div>
      </div>

      <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
        <h3 className="text-lg font-semibold text-slate-100 mb-6">Financial Breakdown</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis tickFormatter={(val) => `₹${val/1000}k`} stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px' }}
                formatter={(val: number) => [formatCurrency(val), 'Value']}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.name === 'Profit' ? '#10b981' : entry.name === 'Cost' ? '#ef4444' : '#3b82f6'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold text-emerald-400">Market Insight: {result.marketData.cropName}</h3>
            <p className="text-xs text-slate-500 uppercase tracking-wider mt-1">Grounding Data: {result.marketData.lastUpdated}</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            result.marketData.marketTrend === 'Up' ? 'bg-emerald-500/10 text-emerald-400' :
            result.marketData.marketTrend === 'Down' ? 'bg-red-500/10 text-red-400' :
            'bg-slate-500/10 text-slate-400'
          }`}>
            Trend: {result.marketData.marketTrend}
          </span>
        </div>
        
        <div className="bg-slate-900/50 p-4 rounded-xl mb-4 border border-slate-700">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">₹{result.marketData.currentPrice}</span>
            <span className="text-slate-400 text-sm">/ {result.marketData.priceUnit}</span>
          </div>
        </div>

        <p className="text-slate-300 text-sm leading-relaxed italic mb-4">
          "{result.marketData.analysis}"
        </p>

        {result.marketData.sourceUrls.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-700">
            <p className="text-xs font-semibold text-slate-500 mb-2">VERIFIED SOURCES</p>
            <div className="flex flex-wrap gap-2">
              {result.marketData.sourceUrls.map((url, i) => (
                <a 
                  key={i} 
                  href={url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-xs text-emerald-500 hover:underline truncate max-w-[200px]"
                >
                  Source {i + 1}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
