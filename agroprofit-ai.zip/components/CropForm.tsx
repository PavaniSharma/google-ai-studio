
import React, { useState } from 'react';
import { CropEntry } from '../types';

interface CropFormProps {
  onSubmit: (data: CropEntry) => void;
  isLoading: boolean;
}

const CropForm: React.FC<CropFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<Omit<CropEntry, 'id'>>({
    name: '',
    yield: 0,
    yieldUnit: 'Quintal',
    estimatedCost: 0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || formData.yield <= 0) return;
    
    onSubmit({
      ...formData,
      id: Math.random().toString(36).substr(2, 9)
    });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 backdrop-blur-sm">
      <h2 className="text-xl font-semibold mb-6 text-emerald-400">Add Crop Details</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Crop Name</label>
          <input
            type="text"
            required
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            placeholder="e.g. Wheat, Paddy, Tomato"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Total Yield (Gain)</label>
            <input
              type="number"
              required
              min="0.1"
              step="0.1"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              value={formData.yield || ''}
              onChange={(e) => setFormData({ ...formData, yield: parseFloat(e.target.value) })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Unit</label>
            <select
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              value={formData.yieldUnit}
              onChange={(e) => setFormData({ ...formData, yieldUnit: e.target.value as any })}
            >
              <option value="Quintal">Quintal</option>
              <option value="Kg">Kg</option>
              <option value="Ton">Ton</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-400 mb-1">Total Production Cost (INR)</label>
          <input
            type="number"
            required
            min="0"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            placeholder="Seeds, Fertilizer, Labour, etc."
            value={formData.estimatedCost || ''}
            onChange={(e) => setFormData({ ...formData, estimatedCost: parseFloat(e.target.value) })}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-colors mt-4 flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing Markets...
            </>
          ) : 'Calculate Profit'}
        </button>
      </div>
    </form>
  );
};

export default CropForm;
