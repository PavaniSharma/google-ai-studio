
import { GoogleGenAI, Type } from "@google/genai";
import { MarketData } from "../types";

export const fetchMarketInsights = async (cropName: string): Promise<MarketData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Find the latest average market price (Mandi price) for ${cropName} in India (INR) for today. 
  Include market trends and a short analysis of why prices are moving. 
  Return the information as JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            cropName: { type: Type.STRING },
            currentPrice: { type: Type.NUMBER, description: "Price in INR per Quintal" },
            priceUnit: { type: Type.STRING, description: "Should be 'Quintal'" },
            marketTrend: { type: Type.STRING, enum: ["Up", "Down", "Stable"] },
            analysis: { type: Type.STRING },
            sourceUrls: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "List of web URLs found during grounding"
            }
          },
          required: ["cropName", "currentPrice", "priceUnit", "marketTrend", "analysis"]
        }
      }
    });

    const result = JSON.parse(response.text);
    
    // Extract real URLs from grounding metadata if available
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const urls = groundingChunks?.map((chunk: any) => chunk.web?.uri).filter(Boolean) || [];

    return {
      ...result,
      sourceUrls: urls.length > 0 ? urls : (result.sourceUrls || []),
      lastUpdated: new Date().toLocaleDateString()
    };
  } catch (error) {
    console.error("Error fetching market data:", error);
    throw new Error("Failed to fetch real-time market data. Please try again later.");
  }
};
